# Birthday Website

1. Open index.html.
2. In the CONFIG section near the bottom, change:
   name: "Name"
   age: "21"
   music: "music.mp3"
3. Put your MP3 in the same folder and name it music.mp3.
4. To add real photos, replace the four `.art` blocks with `<img>` tags and put the images in the same folder.
5. Upload the folder to GitHub Pages, Netlify, or another static host to share it.

The navigation, animations, mobile layout, birthday cover, age chapter, envelope, letter and memories flow are already wired up.
